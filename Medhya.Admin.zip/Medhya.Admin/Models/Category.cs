﻿namespace Medhya.Admin.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public string? CategoryStatus { get; set; }
    }
}
